Runke · Lenk- und Ruhezeiten-Prüfer

So öffnest du die App:
1. ZIP-Datei entpacken oder die HTML-Datei direkt herunterladen.
2. lenk_ruhezeiten_app_runke.html doppelt anklicken.
3. Die App öffnet sich im Browser.

Enthalten:
- Alle 46 erkannten Runke-Arbeitsdienste aus der Planungsübersicht 13.04.2026 bis 01.07.2026.
- Der Dienst 3095 ist als Nachtdienst 20:20 bis 04:05 hinterlegt.
- Pausen und Lenkblöcke sind leer, weil diese in der Planungsübersicht nicht enthalten sind.

Wichtig:
- Trage Pausen manuell ein, z. B. 09:15-09:45 12:00-12:15 oder 15 30.
- Trage Lenkblöcke manuell ein, z. B. 2:15 2:10 1:40.
- Erst danach kann die App Pausen, Fahrtunterbrechungen und Ein-Sechstel-Regelung sinnvoll prüfen.
