Lenk- und Ruhezeiten-Prüfer mit Ein-Sechstel-Regelung

So öffnest du die App:
1. ZIP-Datei entpacken oder die HTML-Datei direkt herunterladen.
2. lenk_ruhezeiten_app_ein_sechstel.html doppelt anklicken.
3. Die App öffnet sich im Browser.

Neue Funktion:
- Pro Dienst kann bei Linienverkehr bis 50 km die Fahrtunterbrechungsregel gewählt werden:
  - Automatisch nach Haltestellenabstand
  - Blockregel: 30 Minuten, 2 × 20 Minuten oder 3 × 15 Minuten
  - Ein-Sechstel-Regelung

Ein-Sechstel-Regelung:
- Die anrechenbaren Arbeitsunterbrechungen müssen zusammen mindestens 1/6 der eingetragenen Lenkzeit betragen.
- Unterbrechungen unter 10 Minuten zählen nicht.
- Wenn eine passende Tarifregel vorhanden ist, können Unterbrechungen ab 8 Minuten gezählt werden.
- Die App prüft diese Regel als Vorprüfung anhand deiner eingetragenen Lenkblöcke und Pausen.

Hinweis:
Für eine vollständige Prüfung müssen Lenkzeit, Arbeitszeit, Bereitschaft, Pausen und Ruhezeiten korrekt eingetragen werden.
