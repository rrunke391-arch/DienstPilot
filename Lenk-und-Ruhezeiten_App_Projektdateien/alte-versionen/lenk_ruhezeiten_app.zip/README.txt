Lenk- und Ruhezeiten-Prüfer für Busfahrer

So öffnest du die App:
1. ZIP-Datei entpacken.
2. Die Datei lenk_ruhezeiten_app.html doppelt anklicken.
3. Die App öffnet sich im Browser.

Hinweise:
- Es ist keine Installation notwendig.
- Es wird keine Internetverbindung benötigt.
- Die Prüfung funktioniert nur so gut wie die eingetragenen Daten.
- Für die echte Prüfung müssen Lenkblöcke und Pausen korrekt eingetragen werden.
