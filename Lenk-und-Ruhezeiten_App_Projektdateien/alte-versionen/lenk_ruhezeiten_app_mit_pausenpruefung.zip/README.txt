Lenk- und Ruhezeiten-Prüfer mit zusätzlicher Pausenprüfung

So öffnest du die App:
1. ZIP-Datei entpacken oder die HTML-Datei direkt herunterladen.
2. lenk_ruhezeiten_app_mit_pausenpruefung.html doppelt anklicken.
3. Die App öffnet sich im Browser.

Neue Funktionen:
- Eigene Dienstvorlagen mit Dienstnummer, Dienstanfang und Dienstende speichern.
- Zusätzliche Dienstzeit-Pausenprüfung:
  - bis 6 Stunden: keine Mindestpause in dieser vereinfachten Prüfung
  - mehr als 6 bis 9 Stunden: mindestens 30 Minuten Pause
  - mehr als 9 Stunden: mindestens 45 Minuten Pause
  - Teilpausen zählen ab 15 Minuten
- Warnung/Verstoß, wenn zu wenig Pause eingetragen wurde.

Hinweis:
Die App ist eine Vorprüfung. Dienstzeit ist nicht immer identisch mit Arbeitszeit oder Lenkzeit. Für eine genaue Prüfung müssen Lenkblöcke, Pausen, Bereitschaftszeiten und Arbeitszeiten korrekt eingetragen werden.
