Lenk- und Ruhezeiten-Prüfer mit manueller Pauseneingabe

So öffnest du die App:
1. ZIP-Datei entpacken oder die HTML-Datei direkt herunterladen.
2. lenk_ruhezeiten_app_manuelle_pausen.html doppelt anklicken.
3. Die App öffnet sich im Browser.

Pausen manuell eingeben:
- Als Minutenwerte: 15 30
- Als Uhrzeit-Bereiche: 09:15-09:45 12:00-12:15
- Gemischt ist ebenfalls möglich.
- Die App rechnet Uhrzeit-Bereiche automatisch in Minuten um.

Die App prüft:
- Mindestpause nach Dienstzeit
- Fahrtunterbrechungen nach EU-Regel oder Linienverkehrsregel
- Ein-Sechstel-Regelung im Linienverkehr bis 50 km
- Ruhezeit zwischen Diensten
- Tages-, Wochen- und 14-Tage-Lenkzeit

Hinweis:
Die App ist eine Vorprüfung. Die Prüfung ist nur so genau wie die eingegebenen Lenkblöcke, Pausen und Dienstzeiten.
